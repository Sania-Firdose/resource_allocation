package com.java.resource_allocation.service;
import com.java.resource_allocation.model.Resource;
import com.java.resource_allocation.repository.ResourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class ResourceService {

    @Autowired
    private ResourceRepository repository;

    public List<Resource> getFilteredResources(List<String> skills, int maxExperience) {
        return repository.findBySkillsAndExperience(skills, maxExperience);


    }


}





