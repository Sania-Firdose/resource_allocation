package com.java.resource_allocation.repository;
import com.java.resource_allocation.model.Resource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ResourceRepository extends JpaRepository<Resource, Long> {
@Query("SELECT r FROM Resource r WHERE r.experienceYears < :maxExperience " +
        "AND (:skills IS NULL OR EXISTS (SELECT s FROM r.skills s WHERE s IN :skills))")
List<Resource> findBySkillsAndExperience(@Param("skills") List<String> skills,
                                             @Param("maxExperience") int maxExperience);


}



