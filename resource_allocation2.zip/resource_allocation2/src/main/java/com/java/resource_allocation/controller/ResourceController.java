package com.java.resource_allocation.controller;

import com.java.resource_allocation.model.Resource;
import com.java.resource_allocation.service.ResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/resources")
public class ResourceController {

    @Autowired
    private ResourceService service;

    @GetMapping("/filter")
    public ResponseEntity<List<Resource>> filterResources(
            @RequestParam List<String> skills,
            @RequestParam(required = false) Integer maxExperience) {
        return ResponseEntity.ok(service.getFilteredResources(skills, maxExperience));
    }
}










